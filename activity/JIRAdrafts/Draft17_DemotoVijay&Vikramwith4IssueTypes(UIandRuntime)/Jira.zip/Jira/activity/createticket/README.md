# Jira-Create Ticket
This activity provides your flogo application to create ticket in JIRA domain.