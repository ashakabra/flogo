# Jira-Query Ticket
This activity provides your flogo application to query in JIRA domain.